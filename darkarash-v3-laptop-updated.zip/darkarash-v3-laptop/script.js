// =========================
// Safe localStorage helpers
// All reads/writes go through these — prevents crashes on corrupted data or private browsing
// =========================
const store = {
  get(key, fallback = null) {
    try { const v = localStorage.getItem(key); return v !== null ? v : fallback; }
    catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, value); return true; }
    catch { return false; }
  },
  remove(key) {
    try { localStorage.removeItem(key); } catch { /* silent */ }
  },
  getJSON(key, fallback = null) {
    try { const v = localStorage.getItem(key); return v !== null ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  setJSON(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch { return false; }
  }
};

// =========================
// Safe URL validator — prevents javascript: and data: href injection
// =========================
function isSafeUrl(url) {
  if (!url || typeof url !== 'string') return false;
  try {
    const u = new URL(url);
    return ['http:', 'https:'].includes(u.protocol);
  } catch { return false; }
}

// =========================
// DOM Elements
// =========================
const clockEl     = document.getElementById('clock');
const dateEl      = document.getElementById('date');
const greetingEl  = document.getElementById('greeting');
const searchForm  = document.getElementById('search-form');
const searchInput = searchForm?.querySelector('input[type="search"]');
const engineBtns  = searchForm?.querySelectorAll('.engine-icons button') ?? [];

const appsToggle = document.getElementById('google-apps-btn');
const appsPanel  = document.getElementById('google-apps-popup');

const settingsBtn   = document.getElementById('settings-btn');
const settingsPanel = document.getElementById('settings-panel');

const todoIcon   = document.getElementById('todo-icon');
const toggleBtn  = document.getElementById('todo-toggle');
const panel      = document.getElementById('todo-panel');
const todoForm   = document.getElementById('todo-form');
const todoInput  = document.getElementById('todo-input');
const todoList   = document.getElementById('todo-list');

const motivationEl = document.getElementById('motivation');

// Guard: abort early if critical elements are missing (e.g. wrong page)
if (!clockEl || !searchForm) {
  console.warn('[NewTab] Critical DOM elements missing. Script halted.');
  throw new Error('Critical DOM missing');
}

// =========================
// Settings Panel
// =========================
if (settingsBtn && settingsPanel) {
  settingsBtn.onclick = () => {
    const open = settingsPanel.style.display === 'flex';
    settingsPanel.style.display = open ? 'none' : 'flex';
  };
}

// =========================
// Color utility
// =========================
function getHoverColor(hex, amount = -15) {
  // Normalize shorthand hex (#fff → #ffffff)
  if (typeof hex !== 'string') return '#888888';
  hex = hex.trim();
  if (/^#[0-9a-fA-F]{3}$/.test(hex)) {
    hex = '#' + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return hex;

  let r = parseInt(hex.slice(1, 3), 16) / 255;
  let g = parseInt(hex.slice(3, 5), 16) / 255;
  let b = parseInt(hex.slice(5, 7), 16) / 255;

  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) { h = s = 0; }
  else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      default: h = (r - g) / d + 4;
    }
    h /= 6;
  }

  l = Math.min(1, Math.max(0, l + amount / 100));
  let r1, g1, b1;
  if (s === 0) { r1 = g1 = b1 = l; }
  else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r1 = hue2rgb(p, q, h + 1 / 3);
    g1 = hue2rgb(p, q, h);
    b1 = hue2rgb(p, q, h - 1 / 3);
  }
  return `rgb(${Math.round(r1 * 255)},${Math.round(g1 * 255)},${Math.round(b1 * 255)})`;
}

function applyAccent(color) {
  if (!color) return;
  document.documentElement.style.setProperty('--accent', color);
  document.documentElement.style.setProperty('--accent-hover', getHoverColor(color, -15));
  const path = todoIcon?.querySelector('path');
  if (path) path.setAttribute('fill', color);
}

// =========================
// Text Gradient (Shade)
// =========================
function applyShade(on) {
  document.body.classList.toggle('text-shade', !!on);
}

// =========================
// Google Font loader
// =========================
const DEFAULT_FONT_STACK = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
let googleFontLinkEl = null;

// Accepts a fonts.google.com specimen URL, a fonts.googleapis.com css2 URL,
// or a plain font family name. Returns {familyName, cssHref} or null.
function parseGoogleFontInput(input) {
  if (!input || typeof input !== 'string') return null;
  input = input.trim();
  if (!input) return null;

  let familyName = null;
  let cssHref = null;

  try {
    const u = new URL(input);
    if (!['http:', 'https:'].includes(u.protocol)) return null;

    if (u.hostname.includes('fonts.googleapis.com')) {
      cssHref = u.toString();
      const familyParam = u.searchParams.get('family');
      familyName = familyParam ? familyParam.split(':')[0].replace(/\+/g, ' ').trim() : null;
    } else if (u.hostname.includes('fonts.google.com')) {
      const parts = u.pathname.split('/').filter(Boolean);
      const idx = parts.indexOf('specimen');
      if (idx !== -1 && parts[idx + 1]) {
        familyName = decodeURIComponent(parts[idx + 1]).replace(/\+/g, ' ').trim();
      }
    } else {
      return null; // unsupported domain — refuse rather than guess
    }
  } catch {
    // Not a valid URL — treat the raw text as a plain font family name
    familyName = input.replace(/["']/g, '').trim();
  }

  if (!familyName) return null;
  if (!cssHref) {
    const encoded = encodeURIComponent(familyName).replace(/%20/g, '+');
    cssHref = `https://fonts.googleapis.com/css2?family=${encoded}:wght@400;500;600;700&display=swap`;
  }
  return { familyName, cssHref };
}

// Applies (or clears, when familyName/cssHref are falsy) the custom Google Font.
function applyGoogleFont(familyName, cssHref) {
  if (!familyName || !cssHref) {
    if (googleFontLinkEl) { googleFontLinkEl.remove(); googleFontLinkEl = null; }
    document.documentElement.style.removeProperty('--font-family');
    return;
  }
  if (!googleFontLinkEl) {
    googleFontLinkEl = document.createElement('link');
    googleFontLinkEl.rel = 'stylesheet';
    googleFontLinkEl.id = 'google-font-link';
    document.head.appendChild(googleFontLinkEl);
  }
  googleFontLinkEl.href = cssHref;
  document.documentElement.style.setProperty('--font-family', `"${familyName}", ${DEFAULT_FONT_STACK}`);
}

// =========================
// Matrix Rain — lightweight canvas effect, top-right corner only
// - No React, no per-frame allocations beyond a small drops array
// - 20fps ceiling, pauses when tab/canvas isn't visible
// - When off: no rAF, no listeners, canvas buffer freed — zero cost
// - Trail fade uses 'destination-out' compositing, which erodes the
//   alpha of previously-drawn glyphs instead of painting a dark
//   rectangle over the canvas — so there is never a dark box, only
//   the falling characters themselves.
// =========================
(function () {
  const canvas      = document.getElementById('matrix-rain-canvas');
  const toggleBtn   = document.getElementById('matrix-toggle-btn');
  const colorPicker = document.getElementById('matrix-color-picker');

  const opacityDecBtn  = document.getElementById('matrix-opacity-decrement');
  const opacityIncBtn  = document.getElementById('matrix-opacity-increment');
  const opacityValueEl = document.getElementById('matrix-opacity-value');

  const fontDecBtn  = document.getElementById('matrix-fontsize-decrement');
  const fontIncBtn  = document.getElementById('matrix-fontsize-increment');
  const fontValueEl = document.getElementById('matrix-fontsize-value');

  if (!canvas) return;

  const DEFAULT_COLOR = '#00ff41';
  // Exact glyph set from the reference React component
  const GLYPHS = '01アイウエオカキクケコサシスセソ$#+*<>[]{}';

  // Column spacing is fixed and NEVER changes with font size — only the
  // rendered glyph size changes, per spec ("only font size, not distance
  // among each rain").
  const COLUMN_PITCH = 15; // horizontal distance between rain streams
  const ROW_PITCH = 26;    // vertical distance between characters in a stream
  const FONT_MIN = 8, FONT_MAX = 28, FONT_STEP = 1;
  const OPACITY_MIN = 5, OPACITY_MAX = 100, OPACITY_STEP = 5;

  const ctx = canvas.getContext('2d', { alpha: true });
  const frameInterval = 1000 / 20; // ~20fps ceiling

  let width = 0, height = 0, drops = [];
  let rafId = null;
  let running = false;   // engine loop active
  let visible = true;    // canvas/tab currently visible
  let lastFrame = 0;
  let resizeTimer = null;
  let io = null;

  let color = DEFAULT_COLOR;
  let fontSize = parseInt(store.get('matrixFontSize'), 10);
  if (isNaN(fontSize)) fontSize = 15;
  fontSize = Math.min(FONT_MAX, Math.max(FONT_MIN, fontSize));

  let opacityPct = parseInt(store.get('matrixOpacity'), 10);
  if (isNaN(opacityPct)) opacityPct = 90;
  opacityPct = Math.min(OPACITY_MAX, Math.max(OPACITY_MIN, opacityPct));

  function hexToRgba(hex, alpha) {
    let h = (hex || '').replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const num = parseInt(h, 16);
    if (isNaN(num)) return `rgba(0,255,65,${alpha})`;
    const r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
    return `rgba(${r},${g},${b},${alpha})`;
  }

  function applyOpacityUI(pct) {
    if (opacityValueEl) opacityValueEl.textContent = `${pct}%`;
    if (running) canvas.style.opacity = (pct / 100).toString();
  }

  function applyFontSizeUI(px) {
    if (fontValueEl) fontValueEl.textContent = `${px}px`;
  }

  function resize() {
    const rect = canvas.getBoundingClientRect();
    width = Math.floor(rect.width);
    height = Math.floor(rect.height);
    if (!width || !height) return;
    canvas.width = width;
    canvas.height = height;
    const columns = Math.max(1, Math.floor(width / COLUMN_PITCH));
    drops = new Array(columns).fill(0).map(() => Math.random() * -40);
  }

  function draw(timestamp) {
    if (!running) return;
    rafId = requestAnimationFrame(draw);
    if (!visible) return;
    if (timestamp - lastFrame < frameInterval) return;
    lastFrame = timestamp;

    // Fade existing glyphs toward transparency (never paints a dark
    // background — only erodes what's already drawn).
    ctx.globalCompositeOperation = 'destination-out';
    ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = 'source-over';

    ctx.font = `${fontSize}px monospace`;
    ctx.textBaseline = 'top';

    for (let i = 0; i < drops.length; i++) {
      const glyph = GLYPHS[(Math.random() * GLYPHS.length) | 0];
      const x = i * COLUMN_PITCH;
      const y = drops[i] * ROW_PITCH;
      const leading = Math.random() > 0.93;
      ctx.fillStyle = leading ? 'rgba(224, 231, 255, 1)' : hexToRgba(color, 0.75);
      ctx.fillText(glyph, x, y);
      if (y > height && Math.random() > 0.975) drops[i] = 0;
      else drops[i]++;
    }
  }

  function onResize() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if (running) resize(); }, 200);
  }

  function onVisibility() {
    visible = document.visibilityState === 'visible';
  }

  function start() {
    if (running) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    running = true;
    canvas.style.opacity = (opacityPct / 100).toString();
    resize();
    lastFrame = 0;
    window.addEventListener('resize', onResize);
    document.addEventListener('visibilitychange', onVisibility);
    if (!io) {
      io = new IntersectionObserver(([entry]) => {
        visible = entry.isIntersecting && document.visibilityState === 'visible';
      }, { threshold: 0 });
    }
    io.observe(canvas);
    onVisibility();
    rafId = requestAnimationFrame(draw);
  }

  function stop() {
    running = false;
    canvas.style.opacity = '0';
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
    window.removeEventListener('resize', onResize);
    document.removeEventListener('visibilitychange', onVisibility);
    clearTimeout(resizeTimer);
    if (io) io.disconnect();
    // Free the backing buffer so an idle rain truly costs nothing
    canvas.width = 0;
    canvas.height = 0;
    drops = [];
  }

  function setToggleUI(on) {
    if (!toggleBtn) return;
    toggleBtn.textContent = on ? 'On' : 'Off';
    toggleBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
    toggleBtn.classList.toggle('on', on);
  }

  // Restore saved color, opacity, font size, and on/off state
  color = store.get('matrixColor', DEFAULT_COLOR);
  if (colorPicker) colorPicker.value = color;
  applyOpacityUI(opacityPct);
  applyFontSizeUI(fontSize);

  const savedOn = store.get('matrixRainOn') === 'true';
  setToggleUI(savedOn);
  if (savedOn) start();

  toggleBtn?.addEventListener('click', () => {
    const next = !running;
    if (next) start(); else stop();
    setToggleUI(next);
    store.set('matrixRainOn', String(next));
  });

  // Live preview while running; persisted alongside the rest of the theme
  colorPicker?.addEventListener('input', e => { color = e.target.value; });

  opacityDecBtn?.addEventListener('click', () => {
    opacityPct = Math.max(OPACITY_MIN, opacityPct - OPACITY_STEP);
    applyOpacityUI(opacityPct);
  });
  opacityIncBtn?.addEventListener('click', () => {
    opacityPct = Math.min(OPACITY_MAX, opacityPct + OPACITY_STEP);
    applyOpacityUI(opacityPct);
  });

  fontDecBtn?.addEventListener('click', () => {
    fontSize = Math.max(FONT_MIN, fontSize - FONT_STEP);
    applyFontSizeUI(fontSize);
  });
  fontIncBtn?.addEventListener('click', () => {
    fontSize = Math.min(FONT_MAX, fontSize + FONT_STEP);
    applyFontSizeUI(fontSize);
  });

  document.getElementById('theme-save-btn')?.addEventListener('click', () => {
    if (colorPicker) store.set('matrixColor', colorPicker.value);
    store.set('matrixOpacity', String(opacityPct));
    store.set('matrixFontSize', String(fontSize));
  });
})();

// =========================
// DOMContentLoaded — Settings wiring
// =========================
let userName = store.get('userName', 'there');

window.addEventListener('DOMContentLoaded', () => {
  const colorPicker    = document.getElementById('color-picker');
  const bgPicker       = document.getElementById('bg-picker');
  const themeSaveBtn   = document.getElementById('theme-save-btn');
  const userNameInput  = document.getElementById('user-name');
  const shadeToggleBtn = document.getElementById('shade-toggle');
  const googleFontInput = document.getElementById('google-font-url');

  // Apply saved accent
  const savedColor = store.get('accentColor');
  if (savedColor) { applyAccent(savedColor); if (colorPicker) colorPicker.value = savedColor; }

  // Apply saved text shade (gradient) setting
  let shadeOn = store.get('textShade') === 'true';
  applyShade(shadeOn);
  if (shadeToggleBtn) {
    shadeToggleBtn.textContent = shadeOn ? 'On' : 'Off';
    shadeToggleBtn.setAttribute('aria-pressed', shadeOn ? 'true' : 'false');
    shadeToggleBtn.classList.toggle('on', shadeOn);
  }
  shadeToggleBtn?.addEventListener('click', () => {
    shadeOn = !shadeOn;
    applyShade(shadeOn);
    shadeToggleBtn.textContent = shadeOn ? 'On' : 'Off';
    shadeToggleBtn.setAttribute('aria-pressed', shadeOn ? 'true' : 'false');
    shadeToggleBtn.classList.toggle('on', shadeOn);
  });

  // Apply saved Google Font
  const savedFontFamily = store.get('googleFontFamily');
  const savedFontHref   = store.get('googleFontHref');
  if (savedFontFamily && savedFontHref) {
    applyGoogleFont(savedFontFamily, savedFontHref);
    if (googleFontInput) googleFontInput.value = savedFontFamily;
  }

  // Apply saved bg
  const savedBg = store.get('bgImage');
  if (savedBg) document.documentElement.style.setProperty('--bg-image', savedBg);

  // =========================
  // Background Blur & Black Overlay steppers
  // =========================
  const blurDecBtn     = document.getElementById('blur-decrement');
  const blurIncBtn     = document.getElementById('blur-increment');
  const blurValueEl    = document.getElementById('blur-value');
  const overlayDecBtn  = document.getElementById('overlay-decrement');
  const overlayIncBtn  = document.getElementById('overlay-increment');
  const overlayValueEl = document.getElementById('overlay-value');

  const BLUR_MIN = 0, BLUR_MAX = Infinity, BLUR_STEP = 1;
  const OVERLAY_MIN = 0, OVERLAY_MAX = 100, OVERLAY_STEP = 5;

  // Load saved values (fallback to current CSS defaults)
  let bgBlur = parseInt(store.get('bgBlur'), 10);
  if (isNaN(bgBlur)) bgBlur = 3;
  bgBlur = Math.min(BLUR_MAX, Math.max(BLUR_MIN, bgBlur));

  let overlayOpacity = parseFloat(store.get('overlayOpacity'));
  if (isNaN(overlayOpacity)) overlayOpacity = 0.192;
  let overlayPct = Math.round(overlayOpacity * 100);
  overlayPct = Math.min(OVERLAY_MAX, Math.max(OVERLAY_MIN, overlayPct));

  function applyBgBlur(px) {
    document.documentElement.style.setProperty('--bg-blur', `${px}px`);
    if (blurValueEl) blurValueEl.textContent = `${px}px`;
  }

  function applyOverlayOpacity(pct) {
    document.documentElement.style.setProperty('--overlay-opacity', (pct / 100).toString());
    if (overlayValueEl) overlayValueEl.textContent = `${pct}%`;
  }

  applyBgBlur(bgBlur);
  applyOverlayOpacity(overlayPct);

  blurDecBtn?.addEventListener('click', () => {
    bgBlur = Math.max(BLUR_MIN, bgBlur - BLUR_STEP);
    applyBgBlur(bgBlur);
  });
  blurIncBtn?.addEventListener('click', () => {
    bgBlur = Math.min(BLUR_MAX, bgBlur + BLUR_STEP);
    applyBgBlur(bgBlur);
  });

  overlayDecBtn?.addEventListener('click', () => {
    overlayPct = Math.max(OVERLAY_MIN, overlayPct - OVERLAY_STEP);
    applyOverlayOpacity(overlayPct);
  });
  overlayIncBtn?.addEventListener('click', () => {
    overlayPct = Math.min(OVERLAY_MAX, overlayPct + OVERLAY_STEP);
    applyOverlayOpacity(overlayPct);
  });

  // Live color preview
  colorPicker?.addEventListener('input', e => applyAccent(e.target.value));

  // BG picker
  let pendingBg = null;
  bgPicker?.addEventListener('change', e => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Limit file size to 5MB to prevent localStorage quota crash
    if (file.size > 5 * 1024 * 1024) {
      alert('Background image must be under 5MB.');
      bgPicker.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = ev => {
      pendingBg = `url(${ev.target.result})`;
      document.documentElement.style.setProperty('--bg-image', pendingBg);
    };
    reader.onerror = () => { pendingBg = null; };
    reader.readAsDataURL(file);
  });

  // Theme save
  themeSaveBtn?.addEventListener('click', () => {
    if (colorPicker) store.set('accentColor', colorPicker.value);
    if (pendingBg) {
      const ok = store.set('bgImage', pendingBg);
      if (!ok) alert('Could not save background — storage may be full.');
      pendingBg = null;
    }
    store.set('bgBlur', String(bgBlur));
    store.set('overlayOpacity', (overlayPct / 100).toString());
    const newName = userNameInput?.value.trim();
    if (newName) {
      store.set('userName', newName);
      userName = newName;
      updateTime(true);
    }

    // Persist text shade (gradient) toggle
    store.set('textShade', String(shadeOn));

    // Parse & persist Google Font
    const fontRaw = googleFontInput?.value.trim();
    if (fontRaw) {
      const parsed = parseGoogleFontInput(fontRaw);
      if (parsed) {
        applyGoogleFont(parsed.familyName, parsed.cssHref);
        store.set('googleFontFamily', parsed.familyName);
        store.set('googleFontHref', parsed.cssHref);
      } else {
        alert('Could not read that as a Google Font link. Paste a link from fonts.google.com, or leave it blank for the default font.');
      }
    } else {
      // Cleared — fall back to the default font
      applyGoogleFont(null, null);
      store.remove('googleFontFamily');
      store.remove('googleFontHref');
    }

    themeSaveBtn.textContent = 'Saved!';
    setTimeout(() => themeSaveBtn.textContent = 'Save Theme', 1500);
  });

  // Tab switching
  document.querySelectorAll('.stab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.stab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.stab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(tab.dataset.tab)?.classList.add('active');
    });
  });

  // Todo panel restore
  const todoVisible = store.get('todoPanelVisible') === 'true';
  setPanelVisibility(todoVisible, false);

  // Custom Quotes settings
  const quotesInput   = document.getElementById('custom-quotes-input');
  const quotesSaveBtn = document.getElementById('quotes-save-btn');
  const quotesError   = document.getElementById('quotes-error');

  if (userNameInput) userNameInput.value = store.get('userName', '');

  // Populate textarea with saved quotes
  if (quotesInput) {
    const saved = store.getJSON('customQuotes', null);
    if (Array.isArray(saved) && saved.length) {
      quotesInput.value = JSON.stringify(saved, null, 2);
    }
  }

  quotesSaveBtn?.addEventListener('click', () => {
    if (!quotesInput || !quotesError) return;
    quotesError.textContent = '';
    const raw = quotesInput.value.trim();

    // Validate JSON
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      quotesError.textContent = 'Invalid JSON — check your format.';
      return;
    }

    if (!Array.isArray(parsed) || parsed.length === 0) {
      quotesError.textContent = 'Must be a non-empty JSON array of strings.';
      return;
    }

    // Filter to strings only
    const quotes = parsed.filter(q => typeof q === 'string' && q.trim().length > 0);
    if (quotes.length === 0) {
      quotesError.textContent = 'No valid string entries found in the array.';
      return;
    }

    const ok = store.setJSON('customQuotes', quotes);
    if (!ok) {
      quotesError.textContent = 'Could not save — storage may be full.';
      return;
    }

    loadQuote();
    quotesSaveBtn.textContent = 'Saved!';
    setTimeout(() => quotesSaveBtn.textContent = 'Save Quotes', 1500);
  });
});

// =========================
// Quote System — custom quotes only, no AI API
// =========================
const FALLBACK_QUOTES = [
  'Discipline or regret. Pick one.',
  'Nobody cares. Work harder.',
  'Burn the boats. No retreat.',
  'Consistency is the only superpower.',
  'The world owes you zero. Earn it.',
  'Obsession beats talent every time.',
  'Pain is the tax for greatness.',
  'Shut up. Put in the work.'
];

function loadQuote() {
  if (!motivationEl) return;

  const custom = store.getJSON('customQuotes', null);
  const pool = (Array.isArray(custom) && custom.length > 0) ? custom : FALLBACK_QUOTES;

  // Rotate by day so quote changes daily but stays consistent within the day
  const d = new Date();
  const idx = (d.getFullYear() * 1000 + d.getMonth() * 31 + d.getDate()) % pool.length;
  motivationEl.textContent = pool[idx];
}

loadQuote();

// =========================
// Google Apps panel toggle
// =========================
if (appsToggle && appsPanel) {
  let isAppsPanelOpen = false;

  appsPanel.setAttribute('tabindex', '-1');
  appsPanel.style.display = 'none';
  appsToggle.setAttribute('aria-expanded', 'false');
  appsPanel.setAttribute('aria-hidden', 'true');

  const setAppsPanel = (open) => {
    isAppsPanelOpen = open;
    appsPanel.style.display = open ? 'grid' : 'none';
    appsToggle.setAttribute('aria-expanded', String(open));
    appsPanel.setAttribute('aria-hidden', String(!open));
    if (open) appsPanel.focus();
  };

  appsToggle.addEventListener('click', e => { e.stopPropagation(); setAppsPanel(!isAppsPanelOpen); });

  document.addEventListener('click', e => {
    if (isAppsPanelOpen && !appsToggle.contains(e.target) && !appsPanel.contains(e.target))
      setAppsPanel(false);
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && isAppsPanelOpen) { setAppsPanel(false); appsToggle.focus(); }
  });
}

// =========================
// Clock + Greeting
// =========================
function formatDate(date) {
  return date.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
}

let lastMinute = -1;
let lastDateStr = '';

function updateTime(force = false) {
  const now = new Date();
  const hours = now.getHours();
  const mins  = now.getMinutes();

  if (!force && mins === lastMinute) return;
  lastMinute = mins;

  if (clockEl) clockEl.textContent = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;

  const dateStr = formatDate(now);
  if (dateStr !== lastDateStr) { lastDateStr = dateStr; if (dateEl) dateEl.textContent = dateStr; }

  if (greetingEl) {
    const greeting = hours < 12 ? 'Good Morning' : hours < 18 ? 'Good Afternoon' : 'Good Evening';
    greetingEl.textContent = `${greeting} ${userName}...`;
  }
}

updateTime();
// Single interval at 10s — no redundant setTimeout
setInterval(updateTime, 10000);

// =========================
// Search Engine Switching
// =========================
const ENGINE_MAP = { G:'google', B:'bing', D:'duckduckgo', Y:'youtube', I:'google-images', YA:'yandex', YI:'yandex-images', S:'shodan' };
const SEARCH_URLS = {
  google: q => q ? `https://www.google.com/search?q=${encodeURIComponent(q)}` : 'https://www.google.com',
  bing:   q => q ? `https://www.bing.com/search?q=${encodeURIComponent(q)}` : 'https://www.bing.com',
  duckduckgo: q => q ? `https://duckduckgo.com/?q=${encodeURIComponent(q)}` : 'https://duckduckgo.com',
  youtube:  q => q ? `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}` : 'https://www.youtube.com',
  'google-images': q => q ? `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(q)}` : 'https://www.google.com/imghp',
  yandex: q => q ? `https://yandex.com/search/?text=${encodeURIComponent(q)}` : 'https://yandex.com',
  'yandex-images': q => q ? `https://yandex.com/images/search?text=${encodeURIComponent(q)}` : 'https://yandex.com/images',
  shodan: q => q ? `https://www.shodan.io/search?query=${encodeURIComponent(q)}` : 'https://www.shodan.io',
};

let currentEngine = 'google';
engineBtns[0]?.classList.add('active');

engineBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    engineBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentEngine = ENGINE_MAP[btn.textContent.trim().toUpperCase()] ?? 'google';
  });
});

searchForm.addEventListener('submit', e => {
  e.preventDefault();
  const query = searchInput?.value.trim() ?? '';
  const urlFn = SEARCH_URLS[currentEngine] ?? SEARCH_URLS.google;
  window.location.href = urlFn(query);
  if (searchInput) searchInput.value = '';
});

// =========================
// Bookmark clicks — safe URL guard
// =========================
document.querySelectorAll('.bookmark-card').forEach(card => {
  card.addEventListener('click', () => {
    const link = card.getAttribute('data-link');
    if (isSafeUrl(link)) window.location.href = link;
  });
});

// =========================
// Todo Panel
// =========================
function setPanelVisibility(show, showForm) {
  if (!panel || !todoForm) return;
  panel.style.display = show ? 'flex' : 'none';
  store.set('todoPanelVisible', String(show));
  todoForm.style.display = showForm ? 'flex' : 'none';
}

let clickTimeout = null;

toggleBtn?.addEventListener('click', () => {
  if (clickTimeout) clearTimeout(clickTimeout);
  clickTimeout = setTimeout(() => {
    const isVisible = panel?.style.display === 'flex';
    setPanelVisibility(!isVisible, false);
  }, 250);
});

toggleBtn?.addEventListener('dblclick', () => {
  if (clickTimeout) clearTimeout(clickTimeout);
  setPanelVisibility(true, true);
});

// =========================
// Todo Data
// Invariant: todos.length === todoChecked.length always enforced on load
// =========================
let todos       = store.getJSON('todos', []);
let todoChecked = store.getJSON('todoChecked', []);

// Repair length mismatch (corrupted state guard)
if (!Array.isArray(todos))       todos = [];
if (!Array.isArray(todoChecked)) todoChecked = [];
while (todoChecked.length < todos.length) todoChecked.push(false);
todoChecked = todoChecked.slice(0, todos.length); // trim excess

function saveTodos() {
  store.setJSON('todos', todos);
  store.setJSON('todoChecked', todoChecked);
}

// PERF: update a single item in the DOM instead of full rebuild on toggle
function renderSingleTodo(li, idx) {
  const checked = !!todoChecked[idx];
  li.classList.toggle('checked', checked);
  const checkbox = li.querySelector('.task-checkbox');
  if (checkbox) {
    checkbox.innerHTML = checked
      ? `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="0.5" y="0.5" width="13" height="13" rx="3.5" fill="rgba(255,169,169,0.2)" stroke="var(--accent)"/><path d="M3 7l3 3 5-5" stroke="var(--accent)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`
      : `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="0.5" y="0.5" width="13" height="13" rx="3.5" stroke="rgba(255,255,255,0.25)"/></svg>`;
  }
}

function renderTodos() {
  if (!todoList) return;
  const fragment = document.createDocumentFragment();

  todos.forEach((todo, idx) => {
    const li = document.createElement('li');
    li.dataset.idx = idx;

    const checkbox = document.createElement('span');
    checkbox.className = 'task-checkbox';

    const span = document.createElement('span');
    span.className = 'task-text';
    span.textContent = todo; // textContent — XSS safe

    const btn = document.createElement('button');
    btn.textContent = '×'; // textContent — XSS safe
    btn.title = 'Delete task';
    btn.onclick = e => {
      e.stopPropagation();
      todos.splice(idx, 1);
      todoChecked.splice(idx, 1);
      saveTodos();
      renderTodos(); // full rebuild only on delete (index shift)
    };

    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(btn);

    li.addEventListener('click', () => {
      todoChecked[idx] = !todoChecked[idx];
      saveTodos();
      renderSingleTodo(li, idx); // ← targeted update, no full rebuild
    });

    renderSingleTodo(li, idx);
    fragment.appendChild(li);
  });

  todoList.innerHTML = '';
  todoList.appendChild(fragment);
}

todoForm?.addEventListener('submit', e => {
  e.preventDefault();
  const val = todoInput?.value.trim();
  if (val) {
    todos.push(val);
    todoChecked.push(false);
    saveTodos();
    if (todoInput) todoInput.value = '';
    renderTodos();
  }
});

renderTodos();

// =========================
// Bookmark Editing
// =========================
const bookmarkCards     = document.querySelectorAll('.bookmark-card');
const bookmarkSelect    = document.getElementById('bookmark-select');
const bookmarkUrlInput  = document.getElementById('bookmark-url-input');
const bookmarkImgUrl    = document.getElementById('bookmark-img-url');
const bookmarkImgFile   = document.getElementById('bookmark-img-file');
const bookmarkSaveBtn   = document.getElementById('bookmark-save-btn');
const bookmarkResetBtn  = document.getElementById('bookmark-reset-btn');
const bookmarkTitleInput= document.getElementById('bookmark-title-input');
const bookmarkColorInput= document.getElementById('bookmark-color-input');

const bookmarkDefaults = [];
bookmarkCards.forEach((card, i) => {
  bookmarkDefaults.push({
    label: card.getAttribute('title') || `Bookmark ${i + 1}`,
    url:   card.getAttribute('data-link') || '',
    img:   card.querySelector('img')?.getAttribute('src') || '',
    color: card.style.getPropertyValue('--border') || ''
  });
});

if (bookmarkSelect) {
  bookmarkCards.forEach((card, i) => {
    const opt = document.createElement('option');
    opt.value = i;
    opt.textContent = card.getAttribute('title') || `Bookmark ${i + 1}`;
    bookmarkSelect.appendChild(opt);
  });
}

function getSavedBookmarks() {
  return store.getJSON('bookmarkOverrides', {});
}

function applyBookmarkOverrides() {
  const saved = getSavedBookmarks();
  bookmarkCards.forEach((card, i) => {
    const override = saved[i];
    if (!override) return;
    if (override.label) card.setAttribute('title', override.label);
    // Guard URLs before applying
    if (override.url && isSafeUrl(override.url)) card.setAttribute('data-link', override.url);
    const img = card.querySelector('img');
    if (img && override.img) img.src = override.img;
    if (override.color) card.style.setProperty('--border', override.color);
    const opt = bookmarkSelect?.options[i];
    if (opt) opt.textContent = override.label || card.getAttribute('title') || `Bookmark ${i + 1}`;
  });
}

applyBookmarkOverrides();

let pendingImgData = null;

bookmarkSelect?.addEventListener('change', () => {
  const i = parseInt(bookmarkSelect.value);
  if (isNaN(i)) return;
  const card = bookmarkCards[i];
  if (!card) return;
  const saved = getSavedBookmarks();
  const override = saved[i] || {};

  pendingImgData = null; // clear pending on selection change
  if (bookmarkUrlInput)  bookmarkUrlInput.value  = override.url || card.getAttribute('data-link') || '';
  if (bookmarkImgUrl)    bookmarkImgUrl.value     = (override.img && !override.img.startsWith('data:')) ? override.img : '';
  if (bookmarkTitleInput)bookmarkTitleInput.value = override.label || card.getAttribute('title') || '';
  if (bookmarkImgFile)   bookmarkImgFile.value    = '';
  if (bookmarkColorInput) {
    const c = override.color || card.style.getPropertyValue('--border') || '#ffffff';
    bookmarkColorInput.value = /^#[0-9a-fA-F]{6}$/.test(c.trim()) ? c.trim() : '#ffffff';
  }
});

bookmarkSelect?.dispatchEvent(new Event('change'));

bookmarkImgFile?.addEventListener('change', e => {
  const file = e.target.files?.[0];
  if (!file) { pendingImgData = null; return; }
  if (file.size > 2 * 1024 * 1024) {
    alert('Bookmark image must be under 2MB.');
    bookmarkImgFile.value = '';
    pendingImgData = null;
    return;
  }
  const reader = new FileReader();
  reader.onload = ev => { pendingImgData = ev.target.result; if (bookmarkImgUrl) bookmarkImgUrl.value = ''; };
  reader.onerror = () => { pendingImgData = null; };
  reader.readAsDataURL(file);
});

bookmarkImgUrl?.addEventListener('input', () => {
  pendingImgData = null;
  if (bookmarkImgFile) bookmarkImgFile.value = '';
});

bookmarkSaveBtn?.addEventListener('click', () => {
  const i = parseInt(bookmarkSelect?.value);
  if (isNaN(i)) return;
  const card = bookmarkCards[i];
  if (!card) return;

  const saved = getSavedBookmarks();
  const newUrl   = bookmarkUrlInput?.value.trim() || '';
  const newImg   = pendingImgData || bookmarkImgUrl?.value.trim() || '';
  const newLabel = bookmarkTitleInput?.value.trim() || '';
  const newColor = bookmarkColorInput?.value || '';

  if (!saved[i]) saved[i] = {};

  // Validate URL before saving
  if (newUrl) {
    if (isSafeUrl(newUrl)) { saved[i].url = newUrl; card.setAttribute('data-link', newUrl); }
    else alert('Invalid URL. Only http/https links are allowed.');
  }
  if (newImg)   { saved[i].img   = newImg; const img = card.querySelector('img'); if (img) img.src = newImg; }
  if (newLabel) { saved[i].label = newLabel; card.setAttribute('title', newLabel); }
  if (newColor) { saved[i].color = newColor; card.style.setProperty('--border', newColor); }

  const ok = store.setJSON('bookmarkOverrides', saved);
  if (!ok) alert('Could not save bookmark — storage may be full.');

  const opt = bookmarkSelect?.options[i];
  if (opt) opt.textContent = newLabel || card.getAttribute('title') || `Bookmark ${i + 1}`;

  bookmarkSaveBtn.textContent = 'Saved!';
  setTimeout(() => bookmarkSaveBtn.textContent = 'Save', 1500);
  pendingImgData = null;
  if (bookmarkImgFile) bookmarkImgFile.value = '';
});

bookmarkResetBtn?.addEventListener('click', () => {
  const i = parseInt(bookmarkSelect?.value);
  if (isNaN(i)) return;
  const card = bookmarkCards[i];
  const def  = bookmarkDefaults[i];
  if (!card || !def) return;

  const saved = getSavedBookmarks();
  delete saved[i];
  store.setJSON('bookmarkOverrides', saved);

  card.setAttribute('data-link', def.url);
  card.setAttribute('title', def.label);
  const img = card.querySelector('img');
  if (img) img.src = def.img;
  if (def.color) card.style.setProperty('--border', def.color);

  if (bookmarkUrlInput)   bookmarkUrlInput.value   = def.url;
  if (bookmarkImgUrl)     bookmarkImgUrl.value      = '';
  if (bookmarkImgFile)    bookmarkImgFile.value     = '';
  if (bookmarkTitleInput) bookmarkTitleInput.value  = def.label;
  if (bookmarkColorInput) bookmarkColorInput.value  = /^#[0-9a-fA-F]{6}$/.test((def.color || '').trim()) ? def.color.trim() : '#ffffff';
  pendingImgData = null;

  const opt = bookmarkSelect?.options[i];
  if (opt) opt.textContent = def.label;

  bookmarkResetBtn.textContent = 'Reset!';
  setTimeout(() => bookmarkResetBtn.textContent = 'Reset to Default', 1500);
});

// =========================
// Todo Panel Drag
// =========================
(function initTodoDrag() {
  if (!panel || !todoForm) return;

  let dragging = false;
  let startX, startY, origLeft, origTop;

  const savedPos = store.getJSON('todoPanelPos', null);
  if (savedPos && typeof savedPos.left === 'number' && typeof savedPos.top === 'number') {
    panel.style.position = 'fixed';
    panel.style.left   = savedPos.left + 'px';
    panel.style.top    = savedPos.top  + 'px';
    panel.style.right  = 'auto';
    panel.style.bottom = 'auto';
  }

  function isViewMode() { return !todoForm || todoForm.style.display === 'none' || todoForm.style.display === ''; }
  function clamp(v, lo, hi) { return Math.min(Math.max(v, lo), hi); }

  function startDrag(clientX, clientY) {
    dragging = true;
    panel.style.position = 'fixed';
    panel.style.right  = 'auto';
    panel.style.bottom = 'auto';
    const rect = panel.getBoundingClientRect();
    panel.style.left = rect.left + 'px';
    panel.style.top  = rect.top  + 'px';
    startX = clientX; startY = clientY;
    origLeft = rect.left; origTop = rect.top;
  }

  function moveDrag(clientX, clientY) {
    if (!dragging) return;
    panel.style.left = clamp(origLeft + clientX - startX, 0, window.innerWidth  - panel.offsetWidth)  + 'px';
    panel.style.top  = clamp(origTop  + clientY - startY, 0, window.innerHeight - panel.offsetHeight) + 'px';
  }

  function endDrag() {
    if (!dragging) return;
    dragging = false;
    panel.style.cursor = '';
    panel.style.userSelect = '';
    store.setJSON('todoPanelPos', { left: parseFloat(panel.style.left), top: parseFloat(panel.style.top) });
  }

  panel.addEventListener('mousedown', e => {
    if (!isViewMode() || e.target.closest('button,input,a,.task-checkbox')) return;
    startDrag(e.clientX, e.clientY);
    panel.style.cursor = 'grabbing';
    panel.style.userSelect = 'none';
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => moveDrag(e.clientX, e.clientY));
  document.addEventListener('mouseup', endDrag);

  panel.addEventListener('touchstart', e => {
    if (!isViewMode() || e.target.closest('button,input,a,.task-checkbox')) return;
    const t = e.touches[0];
    startDrag(t.clientX, t.clientY);
    e.preventDefault();
  }, { passive: false });
  document.addEventListener('touchmove', e => {
    if (!dragging) return;
    moveDrag(e.touches[0].clientX, e.touches[0].clientY);
    e.preventDefault();
  }, { passive: false });
  document.addEventListener('touchend', endDrag);

  panel.addEventListener('mouseover', () => { if (isViewMode() && !dragging) panel.style.cursor = 'grab'; });
  panel.addEventListener('mouseout',  () => { if (!dragging) panel.style.cursor = ''; });
})();